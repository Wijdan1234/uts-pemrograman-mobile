package com.example.formregisterwijdan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText edttxtName;
    EditText edttxtAlamat;
    EditText edttxtWa;

    TextView txtViewName.txtViewAlamat.txtViewWa;

    Button btnRegister;

    @Override
    protected void onCreate(Bundle savedinstanceState) {
        super.onCreate(savedinstanceState);
        setContentView(R.layout.activity_main);

        edttxtName = findViewById(R.id.editTextNama);
        edttxtAlamat = findViewById(R.id.editTextAlamat);
        edttxtWa = findViewById(R.id.editTextWa);

        txtViewName = findViewById(R.id.textViewNama);
        txtViewAlamat = findViewById(R.id.textViewAlamat);
        edttxtWa = findViewById(R.id.textViewWa)
    }
public void onRegisterclick(View view){
        txtViewName.setText("Nama Anda:" +edttxtName.getText().toString());
        txtViewAlamat.setText("Alamat Anda:" +edttxtAlamat.getText().toString());
        txtViewWa.setText("WA Anda:" +edttxtWa.getText().toString());
}
}





